package com.jitcall.jitsiplugin;

import android.util.Log;

public class jitsiplugin {

    public String echo(String value) {
        Log.i("Echo", value);
        return value;
    }
}
