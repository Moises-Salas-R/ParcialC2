package com.jitcall.jitsiplugin;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import android.os.Bundle;
import org.jitsi.meet.sdk.JitsiMeetActivity;
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions;
import org.jitsi.meet.sdk.JitsiMeetUserInfo;
import java.net.URL;

@CapacitorPlugin(name = "jitsiplugin")
public class jitsipluginPlugin extends Plugin {

    @PluginMethod
    public void joinCall(PluginCall call) {
        String room = call.getString("room");
        String serverUrl = call.getString("serverUrl");
        String displayName = call.getString("displayName");

        if (room == null || serverUrl == null || displayName == null) {
            call.reject("Missing parameters");
            return;
        }

        try {
            JitsiMeetUserInfo userInfo = new JitsiMeetUserInfo();
            userInfo.setDisplayName(displayName);

            JitsiMeetConferenceOptions options = new JitsiMeetConferenceOptions.Builder()
                    .setServerURL(new URL(serverUrl))
                    .setRoom(room)
                    .setUserInfo(userInfo)
                    .setWelcomePageEnabled(false)
                    .build();

            getActivity().runOnUiThread(() -> {
                JitsiMeetActivity.launch(getActivity(), options);
                call.resolve();
            });

        } catch (Exception e) {
            call.reject("Error launching call: " + e.getMessage());
        }
    }
}
