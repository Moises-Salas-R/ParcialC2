# jitsi-plugin

Plugin personalizado para lanzar JitsiMeetActivity

## Install

```bash
npm install jitsi-plugin
npx cap sync
```

## API

<docgen-index></docgen-index>

<docgen-api>
<!-- run docgen to generate docs from the source -->
<!-- More info: https://github.com/ionic-team/capacitor-docgen -->
</docgen-api>
