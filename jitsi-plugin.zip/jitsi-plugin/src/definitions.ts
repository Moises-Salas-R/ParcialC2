export interface jitsipluginPlugin {
  joinCall(options: {
    room: string;
    serverUrl: string;
    displayName: string;
  }): Promise<void>;
}
