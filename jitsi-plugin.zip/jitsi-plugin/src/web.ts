import { WebPlugin } from '@capacitor/core';

import type { jitsipluginPlugin } from './definitions';

export class jitsipluginWeb extends WebPlugin implements jitsipluginPlugin {
  async echo(options: { value: string }): Promise<{ value: string }> {
    console.log('ECHO', options);
    return options;
  }
}
