import { registerPlugin } from '@capacitor/core';

import type { jitsipluginPlugin } from './definitions';

const jitsiplugin = registerPlugin<jitsipluginPlugin>('jitsiplugin');

export * from './definitions';
export { jitsiplugin };
